﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MedoNew.Chemist
{
    public partial class EmergencyRequest : System.Web.UI.Page
    {
        DB d1 = new DB();
        DataSet ds, ds1, ds2;

        static string id;

        string date = DateTime.Now.ToShortDateString();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["MId"] != null)
            {

            }
            else
            {
                Response.Redirect("ChemistLogin.aspx");
            }

            string query4 = "Select * from [dbo].[emergency_details] where LocationName='" + Session["locatioid"].ToString()+"'";
            ds = d1.GetDataSet(query4);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Repeater2.DataSource = ds;
                Repeater2.DataBind();
            }
            else
            {
                msg.Visible = true;
            }
        }


    }

}
